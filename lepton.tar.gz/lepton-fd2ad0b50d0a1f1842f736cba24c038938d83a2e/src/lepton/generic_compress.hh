ValidationContinuation generic_compress(const std::vector<uint8_t>*input,
                                        Sirikata::MuxReader::ResizableByteBuffer *lepton_data,
                                        ExitCode *validation_exit_code);
