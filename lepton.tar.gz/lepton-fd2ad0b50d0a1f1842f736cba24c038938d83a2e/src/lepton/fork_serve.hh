#ifndef _WIN32
void fork_serve();
#endif
