class AlignedBlock;
void idct(const AlignedBlock &block, const uint16_t quantization[64], int16_t outp[64], bool ignore_dc);
