namespace Sirikata {
bool installStrictSyscallFilter(bool verbose);
}
