        return result;
    },
    compress: function(data, cb) {
        return this.run(data, cb);
    },
    decompress: function(data, cb) {
        return this.run(data, cb);
    }
};
